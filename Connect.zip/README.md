# "Simple" SocketIOGame

TODO:

* Write a documentation
* Dice of luck
* add sound - Ping!
* Finish Maturita
* Fix jittering
* Responsive resolution support - 1st attempt 24.2.2019

Done:

* Room system
* databse system -> solved using JSONS
* Redifine drawing system (not state one)-> Own SceneManager (will post Engine link here sometime in the future)
* Cleaned code (12.2.2019)
* Animation support (based on SceneManager)
* Added Role Chooser (needs to update -> not working as it should) -> updated (6.1.2019)
* Added Role Chooser communication -> player see descriptions with their roles
* Add Hand of truth
* Add You've gotta point
* Decrease chance of generating same room
* Design overhaul - started 15.1.2019 Ended 31.1.2019
* Addeed transition animations
* Fixed minor bugs
* Fixed major bug
* Added Design for Client and Host
* Folder re-origanization
* Fixed color bug on host
* Fix minor visual bugs
* Fix timing
* Added Endgame situation
* Partially fixed resolution bug
